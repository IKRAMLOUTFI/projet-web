<?php
    session_start();
    include("PDO_projet.php");

    $categoryAdded = false; // Variable pour vérifier si la catégorie a été ajoutée avec succès
    $errorMessage = ''; // Variable pour stocker le message d'erreur

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nom = $_POST['nom'];
        $budget_mensuel = $_POST['budget_mensuel'];
        $depenses_actuelles = $_POST['depenses_actuelles'];

        // Validation des données
        if (empty($nom) || !is_numeric($budget_mensuel) || !is_numeric($depenses_actuelles)) {
            $errorMessage = 'Veuillez remplir correctement tous les champs.';
        } else {
            try {
                // Préparation et exécution de la requête d'insertion
                $stmt = $pdo->prepare('INSERT INTO categories (nom, budget_mensuel, depenses_actuelles)
                                       VALUES (:nom, :budget_mensuel, :depenses_actuelles)');
                $stmt->execute([
                    ':nom' => $nom,
                    ':budget_mensuel' => $budget_mensuel,
                    ':depenses_actuelles' => $depenses_actuelles,
                ]);
                $categoryAdded = true; // Catégorie ajoutée avec succès
            } catch (PDOException $e) {
                $errorMessage = 'Erreur lors de l\'ajout : ' . htmlspecialchars($e->getMessage());
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter une Catégorie</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(145deg, #8E44AD, #2980B9);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 0 20px;
        }

        .form-container {
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            width: 80%;
            max-width: 600px;
            padding: 40px;
            text-align: center;
            animation: slideIn 0.5s ease-out;
        }

        h2 {
            color: #2C3E50;
            font-size: 32px;
            margin-bottom: 25px;
            font-weight: bold;
        }

        .form-group {
            margin-bottom: 20px;
            position: relative;
        }

        .form-group label {
            color: #34495E;
            font-size: 16px;
            margin-bottom: 8px;
            display: block;
            font-weight: bold;
        }

        .form-group input {
            width: 100%;
            padding: 18px;
            background: #F0F0F0;
            border: 2px solid #BDC3C7;
            border-radius: 10px;
            font-size: 16px;
            color: #555;
            transition: 0.3s ease-in-out;
        }

        .form-group input:focus {
            border-color: #2980B9;
            outline: none;
            box-shadow: 0 0 8px rgba(41, 128, 185, 0.5);
        }

        .btn-submit {
            padding: 18px;
            background-color: #2980B9;
            border: none;
            border-radius: 10px;
            color: #fff;
            font-size: 18px;
            width: 100%;
            cursor: pointer;
            margin-top: 20px;
            transition: background-color 0.3s ease;
        }

        .btn-submit:hover {
            background-color: #1F5A7E;
        }

        .message {
            padding: 18px;
            margin-top: 20px;
            border-radius: 10px;
            font-size: 16px;
            color: #fff;
            width: 80%;
            max-width: 600px;
            margin: 20px auto;
        }

        .message.success {
            background-color: #2ECC71;
        }

        .message.error {
            background-color: #E74C3C;
        }

        @keyframes slideIn {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
    </style>
</head>
<body>

<?php if ($categoryAdded): ?>
    <div class="message success">Catégorie ajoutée avec succès !</div>
<?php elseif ($errorMessage): ?>
    <div class="message error"><?php echo $errorMessage; ?></div>
<?php else: ?>
    <div class="form-container">
        <h2>Ajouter une Catégorie</h2>
        <form method="POST" action="">
            <div class="form-group">
                <label for="nom">Nom de la catégorie</label>
                <input type="text" id="nom" name="nom" placeholder="Ex : Alimentation" required>
            </div>
            <div class="form-group">
                <label for="budget_mensuel">Budget mensuel (Dh)</label>
                <input type="number" step="0.01" id="budget_mensuel" name="budget_mensuel" placeholder="Ex : 500.00" required>
            </div>
            <div class="form-group">
                <label for="depenses_actuelles">Dépenses actuelles (Dh)</label>
                <input type="number" step="0.01" id="depenses_actuelles" name="depenses_actuelles" placeholder="Ex : 0.00 si vous n'avez pas de dépenses." required>
            </div>
            <button type="submit" class="btn-submit">Ajouter</button>
        </form>
    </div>
<?php endif; ?>

</body>
</html>
