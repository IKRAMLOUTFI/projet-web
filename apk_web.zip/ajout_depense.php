<?php
    session_start();
    include("PDO_projet.php");

    $expenseAdded = false;
    $errorMessage = ''; 

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nom_depense = $_POST['nom_depense'];
        $montant = $_POST['montant'];
        $datee = $_POST['datee'];
        $categorie_name = $_POST['categorie_name'];
        $mode_paiement = $_POST['mode_paiement'];
        $commentaire = $_POST['commentaire'];

        if (!empty($nom_depense) && is_numeric($montant) && $montant > 0 && !empty($categorie_name)) {
            try {
                $pdo->beginTransaction();

                $stmt = $pdo->prepare("INSERT INTO depenses (nom_depense, montant, datee, categorie_name, mode_paiement, commentaire)
                    VALUES (:nom_depense, :montant, :datee, :categorie_name, :mode_paiement, :commentaire)");
                $stmt->execute([
                    ':nom_depense' => $nom_depense,
                    ':montant' => $montant,
                    ':datee' => $datee,
                    ':categorie_name' => $categorie_name,
                    ':mode_paiement' => $mode_paiement,
                    ':commentaire' => $commentaire,
                ]);

                $updateStmt = $pdo->prepare("UPDATE categories SET depenses_actuelles = depenses_actuelles + :montant
                    WHERE nom = :categorie_name");
                $updateStmt->execute([':montant' => $montant, ':categorie_name' => $categorie_name]);

                $pdo->commit();
                $expenseAdded = true;
            } catch (PDOException $e) {
                $pdo->rollBack();
                $errorMessage = "Erreur lors de l'ajout de la dépense : " . htmlspecialchars($e->getMessage());
            }
        } else {
            $errorMessage = "Veuillez remplir correctement tous les champs.";
        }
    }
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter une Dépense</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(145deg, #8E44AD, #2980B9);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 0 20px;
        }

        .card {
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            width: 80%;
            max-width: 800px;
            padding: 40px;
            text-align: center;
            animation: slideIn 0.5s ease-out;
        }

        h2 {
            color: #2C3E50;
            font-size: 32px;
            margin-bottom: 25px;
            font-weight: bold;
        }

        .form-group {
            margin-bottom: 20px;
            position: relative;
        }

        .form-group label {
            color: #34495E;
            font-size: 16px;
            margin-bottom: 8px;
            display: block;
            font-weight: bold;
        }

        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 18px;
            background: #F0F0F0;
            border: 2px solid #BDC3C7;
            border-radius: 10px;
            font-size: 16px;
            color: #555;
            transition: 0.3s ease-in-out;
        }

        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            border-color: #2980B9;
            outline: none;
            box-shadow: 0 0 8px rgba(41, 128, 185, 0.5);
        }

        .form-group input::placeholder, .form-group textarea::placeholder {
            color: #BDC3C7;
        }

        .btn-submit {
            padding: 18px;
            background-color: #2980B9;
            border: none;
            border-radius: 10px;
            color: #fff;
            font-size: 18px;
            width: 100%;
            cursor: pointer;
            margin-top: 20px;
            transition: background-color 0.3s ease;
        }

        .btn-submit:hover {
            background-color: #1F5A7E;
        }

        .message {
            padding: 18px;
            margin-top: 20px;
            border-radius: 10px;
            font-size: 16px;
            color: #fff;
            width: 80%;
            max-width: 600px;
            margin: 20px auto;
        }

        .message.success {
            background-color: #2ECC71;
        }

        .message.error {
            background-color: #E74C3C;
        }

        .row {
            display: flex;
            gap: 20px;
            justify-content: space-between;
        }

        .column {
            width: 48%;
        }

        @keyframes slideIn {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
    </style>
</head>
<body>

<div class="card">
    <h2>Ajouter une Dépense</h2>
    
    <?php if ($expenseAdded): ?>
        <div class="message success">
            <p>Dépense ajoutée avec succès !</p>
        </div>
    <?php elseif ($errorMessage): ?>
        <div class="message error">
            <p><?php echo $errorMessage; ?></p>
        </div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="row">
            <div class="column">
                <div class="form-group">
                    <label for="nom_depense">Nom de la dépense</label>
                    <input type="text" id="nom_depense" name="nom_depense" placeholder="Ex : Courses" required>
                </div>
                <div class="form-group">
                    <label for="montant">Montant (Dh)</label>
                    <input type="number" step="0.01" id="montant" name="montant" placeholder="Ex : 50.00" required>
                </div>
                <div class="form-group">
                    <label for="datee">Date</label>
                    <input type="date" id="datee" name="datee" placeholder="Ex : 2024-12-28" required>
                </div>
            </div>
            <div class="column">
                <div class="form-group">
                    <label for="categorie_name">Catégorie</label>
                    <select id="categorie_name" name="categorie_name" required>
                        <option value="" disabled selected>Choisissez une catégorie</option>
                        <?php
                        $categories = $pdo->query("SELECT nom FROM categories");
                        while ($cat = $categories->fetch()) {
                            echo "<option value='{$cat['nom']}'>{$cat['nom']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="mode_paiement">Mode de paiement</label>
                    <input type="text" id="mode_paiement" name="mode_paiement" placeholder="Ex : Carte bancaire">
                </div>
                <div class="form-group">
                    <label for="commentaire">Commentaire</label>
                    <textarea id="commentaire" name="commentaire" rows="3" placeholder="Ex : Dépense pour les courses"></textarea>
                </div>
            </div>
        </div>
        <button type="submit" class="btn-submit">Ajouter la Dépense</button>
    </form>
</div>

</body>
</html>
