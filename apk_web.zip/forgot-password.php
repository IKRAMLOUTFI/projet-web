<?php
    session_start();
    include("PDO_projet.php");

    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        $email = $_POST['email'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        // Vérification des champs
        if (empty($email) || empty($new_password) || empty($confirm_password)) {
            echo "<div class='message error'>Tous les champs sont requis.</div>";
        }

        // Vérification des mots de passe
        if ($new_password !== $confirm_password) {
            echo "<div class='message error'>Le nouveau mot de passe et la confirmation ne correspondent pas.</div>";
        } else {
            try {
                // Vérifier si l'adresse e-mail existe
                $query = 'SELECT * FROM users WHERE email = :email';
                $stmt = $pdo->prepare($query);
                $stmt->execute([':email' => $email]);
                $email1 = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($email1) {
                    $updateQuery = 'UPDATE users SET pasword = :new_password WHERE email = :email';
                    $updateStmt = $pdo->prepare($updateQuery);
                    $updateStmt->execute([':email' => $email, ':new_password' => $new_password]);

                    echo "<div class='message success'>Mot de passe mis à jour avec succès.</div>";
                } else {
                    echo "<div class='message error'>Email invalide.</div>";
                }
            } catch (Exception $e) {
                echo "<div class='message error'>Une erreur est survenue : " . $e->getMessage() . "</div>";
            }
        }
    }
?>


<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    body {
        font-family: 'Arial', sans-serif;
        background: #f4f4f9;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        color: #333;
    }

    .message {
        padding: 12px;
        margin: 10px 0;
        border-radius: 6px;
        font-size: 16px;
        text-align: center;
        transition: all 0.3s ease;
    }

    .message.success {
        background-color: #5a70a1; /* Bleu */
        color: #fff;
        border: 2px solid #4a6492;
    }

    .message.error {
        background-color: #f44336; /* Rouge */
        color: #fff;
        border: 2px solid #e53935;
    }

    /* Effet au survol */
    .message:hover {
        opacity: 0.9;
    }
</style>

