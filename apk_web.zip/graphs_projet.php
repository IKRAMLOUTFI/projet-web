<?php
// Démarrer la session
session_start();
include("PDO_projet.php");

// Activer l'affichage des erreurs pour débogage
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    // Récupérer toutes les catégories avec leurs budgets et dépenses
    $categories = $pdo->query("SELECT nom, budget_mensuel, depenses_actuelles FROM categories")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    die("Erreur lors de la récupération des données : " . $e->getMessage());
}

// Préparer les données pour Chart.js
$labels = [];
$budgets = [];
$depenses_actuelles = [];
$percentages = [];

foreach ($categories as $cat) {
    $labels[] = htmlspecialchars($cat['nom']);
    $budgets[] = $cat['budget_mensuel'];
    $depenses_actuelles[] = $cat['depenses_actuelles'];

    // Calculer le pourcentage des dépenses
    $percentages[] = $cat['budget_mensuel'] > 0 
        ? round(($cat['depenses_actuelles'] / $cat['budget_mensuel']) * 100, 1) 
        : 0;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Graphiques des Catégories</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(145deg, #8E44AD, #2980B9);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 0 20px;
        }

        .container {
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            padding: 30px 40px;
            text-align: center;
            width: 90%;
            max-width: 1000px;
            animation: slideIn 0.5s ease-out;
        }

        h1 {
            font-size: 28px;
            margin-bottom: 25px;
            color: #2C3E50;
            font-weight: bold;
        }

        .chart-section {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
        }

        .chart-container {
            width: 20%; /* Réduit encore plus la largeur des graphiques */
            margin-bottom: 30px;
            text-align: center;
        }

        canvas {
            max-width: 100%;
            height: 80px; /* Taille ultra réduite des graphiques */
        }

        .table-container {
            margin-top: 20px;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 0 auto;
            text-align: center;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            font-size: 0.8em;
        }

        th {
            background-color: #2c3e50;
            color: white;
        }

        td {
            background-color: #ecf0f1;
        }

        .message {
            text-align: center;
            margin-top: 20px;
            padding: 15px;
            background-color: #27ae60;
            color: white;
            font-weight: bold;
            border-radius: 8px;
        }

        @keyframes slideIn {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Graphiques des Budgets et Dépenses</h1>
        
        <div class="chart-section">
            <?php foreach ($categories as $index => $cat): ?>
                <div class="chart-container">
                    <h2><?= htmlspecialchars($cat['nom']) ?></h2>
                    <canvas id="chart-<?= $index ?>"></canvas>
                    <p><strong><?= $percentages[$index] ?>%</strong> du budget utilisé</p>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Catégorie</th>
                        <th>Budget Mensuel (Dhs)</th>
                        <th>Dépenses Actuelles (Dhs)</th>
                        <th>Pourcentage Utilisé (%)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($categories as $index => $cat): ?>
                        <tr>
                            <td><?= htmlspecialchars($cat['nom']) ?></td>
                            <td><?= htmlspecialchars($cat['budget_mensuel']) ?></td>
                            <td><?= htmlspecialchars($cat['depenses_actuelles']) ?></td>
                            <td><?= $percentages[$index] ?>%</td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        const categories = <?= json_encode($labels) ?>;
        const budgets = <?= json_encode($budgets) ?>;
        const depensesActuelles = <?= json_encode($depenses_actuelles) ?>;
        const percentages = <?= json_encode($percentages) ?>;

        // Générer un graphique en anneau pour chaque catégorie
        categories.forEach((category, index) => {
            const ctx = document.getElementById(`chart-${index}`).getContext('2d');
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['Dépenses Actuelles', 'Budget Restant'],
                    datasets: [{
                        data: [
                            depensesActuelles[index], 
                            Math.max(0, budgets[index] - depensesActuelles[index])
                        ],
                        backgroundColor: ['#e74c3c', '#3498db'],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            display: true,
                            position: 'bottom',
                            labels: {
                                fontColor: '#34495e'
                            }
                        },
                        tooltip: {
                            callbacks: {
                                label: function(tooltipItem) {
                                    return `${tooltipItem.label}: ${tooltipItem.raw} Dhs`;
                                }
                            }
                        }
                    },
                    cutout: '70%',  // Augmenter l'espace vide au centre pour un look plus épuré
                }
            });
        });
    </script>
</body>
</html>
