<?php
    session_start();
    include("PDO_projet.php");
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = $_POST['username'] ?? '';
        $pasword = $_POST['pasword'] ?? '';

        if (isset($_POST['forgot_password'])) {
            header("Location: forgot_password.html");
        } elseif (isset($_POST['signup'])) {
            header("Location: signup.html");
        } elseif (!empty($username) && !empty($pasword)){
            try {
                $query = 'SELECT * FROM users WHERE username =:username AND pasword=:pasword';
                $stmt = $pdo->prepare($query);
                $stmt->execute([
                    'username' => $username,
                    'pasword' => $pasword
                ]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($user) {
                    setcookie("user_name", $username,time()+3600, "/", "", true, true) ;
                    header('location:acceuil_projet.html');
                } else {
                    echo "Mot de passe incorrect.";
                    header("Location: test11.html");
                }
            } catch (Exception $e) {
                echo "Une erreur est survenue : " . $e->getMessage();
            }
        }else{
            echo "Both username and password are required.";
        }
    } 
    else {
        echo "Méthode de requête invalide.";
    }
?>
