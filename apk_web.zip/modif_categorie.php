<?php
session_start();
include("PDO_projet.php");

$message = '';
$message_type = '';
$show_form = true; // Affiche le formulaire par défaut

// Récupérer toutes les catégories pour affichage
$categories = $pdo->query("SELECT * FROM categories")->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom_categorie = $_POST['nom'];
    $nouveau_budget = $_POST['budget_mensuel'];

    try {
        // Mettre à jour la catégorie
        $sql = "UPDATE categories SET budget_mensuel = :budget WHERE nom = :nom";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':budget' => $nouveau_budget,
            ':nom' => $nom_categorie
        ]);

        // Succès
        $message = "La catégorie a été mise à jour avec succès.";
        $message_type = 'success';
        $show_form = false; // Cache le formulaire après succès
    } catch (Exception $e) {
        // Échec
        $message = "Une erreur est survenue : " . $e->getMessage();
        $message_type = 'error';
        $show_form = false; // Cache également le formulaire en cas d'erreur
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier une Catégorie</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(145deg, #8E44AD, #2980B9);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 0 20px;
        }

        .container {
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            padding: 30px 40px;
            text-align: center;
            width: 80%;
            max-width: 600px;
            animation: slideIn 0.5s ease-out;
        }

        h1 {
            font-size: 28px;
            margin-bottom: 25px;
            color: #2C3E50;
            font-weight: bold;
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
        }

        label {
            font-size: 16px;
            font-weight: bold;
            color: #555;
        }

        select, input {
            width: 100%;
            padding: 12px;
            border: 2px solid #ccc;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }

        select:focus, input:focus {
            border-color: #2980B9;
            outline: none;
        }

        button {
            width: 100%;
            padding: 15px;
            background-color: #FF6347;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: bold;
            text-transform: uppercase;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #FF4500;
        }

        .message {
            margin-top: 20px;
            padding: 15px;
            border-radius: 8px;
            font-size: 16px;
        }

        .message.success {
            background-color: #5cb85c;
            color: white;
            border: 2px solid #4cae4c;
        }

        .message.error {
            background-color: #f44336;
            color: white;
            border: 2px solid #e53935;
        }

        @keyframes slideIn {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Modifier une Catégorie</h1>
        
        <?php if ($show_form): ?>
            <form method="POST">
                <label for="nom">Sélectionnez une Catégorie :</label>
                <select name="nom" id="nom" required>
                    <option value="" disabled selected>Choisissez une catégorie</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= htmlspecialchars($cat['nom']) ?>"><?= htmlspecialchars($cat['nom']) ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="budget_mensuel">Nouveau Budget Mensuel :</label>
                <input type="number" name="budget_mensuel" id="budget_mensuel" step="0.01" required>

                <button type="submit">Modifier</button>
            </form>
        <?php else: ?>
            <div class="message <?= htmlspecialchars($message_type) ?>">
                <?= htmlspecialchars($message) ?>
            </div>
            <a href="modif_categorie.php" class="btn"><?= $message_type === 'success' ? 'Retour' : 'Réessayer' ?></a>
        <?php endif; ?>
    </div>
</body>
</html>
