<?php
session_start();
include("PDO_projet.php");

$message = '';
$message_type = '';
$show_form = true; // Affiche le formulaire par défaut

// Affichage des erreurs pour débogage
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom_depense = $_POST['nom_depense'];
    $montant = $_POST['montant'];
    $categorie_name = $_POST['categorie_name'];
    $mode_paiement = $_POST['mode_paiement'];
    $commentaire = $_POST['commentaire'];

    try {
        // Récupérer l'ancien montant, la catégorie et le budget de la dépense avant la mise à jour
        $stmt = $pdo->prepare("SELECT montant, categorie_name FROM depenses WHERE nom_depense = :nom_depense");
        $stmt->execute([':nom_depense' => $nom_depense]);
        $old_depense = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($old_depense) {
            $old_montant = $old_depense['montant'];
            $old_categorie_name = $old_depense['categorie_name'];

            // Mettre à jour la dépense avec le nouveau montant et la nouvelle catégorie
            $sql = "UPDATE depenses 
                    SET montant = :montant, 
                        categorie_name = :categorie_name, 
                        mode_paiement = :mode_paiement, 
                        commentaire = :commentaire 
                    WHERE nom_depense = :nom_depense";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':montant' => $montant,
                ':categorie_name' => $categorie_name,
                ':mode_paiement' => $mode_paiement,
                ':commentaire' => $commentaire,
                ':nom_depense' => $nom_depense
            ]);

            // Récupérer le budget actuel de la catégorie de la dépense
            $stmt = $pdo->prepare("SELECT depenses_actuelles FROM categories WHERE nom = :categorie_name");
            $stmt->execute([':categorie_name' => $old_categorie_name]);
            $old_category = $stmt->fetch(PDO::FETCH_ASSOC);
            $old_budget = $old_category['depenses_actuelles'];

            // Mettre à jour le budget de la catégorie avec le nouveau montant
            if ($old_categorie_name !== $categorie_name) {
                // Mettre à jour l'ancienne catégorie (déduire l'ancien montant)
                $updateOldCategoryStmt = $pdo->prepare("UPDATE categories SET depenses_actuelles = depenses_actuelles - :old_montant WHERE nom = :old_categorie_name");
                $updateOldCategoryStmt->execute([':old_montant' => $old_montant, ':old_categorie_name' => $old_categorie_name]);

                // Mettre à jour la nouvelle catégorie (ajouter le nouveau montant)
                $updateNewCategoryStmt = $pdo->prepare("UPDATE categories SET depenses_actuelles = depenses_actuelles + :montant WHERE nom = :categorie_name");
                $updateNewCategoryStmt->execute([':montant' => $montant, ':categorie_name' => $categorie_name]);
            } else {
                // Si la catégorie n'a pas changé, simplement ajuster le budget
                $updateCategoryStmt = $pdo->prepare("UPDATE categories SET depenses_actuelles = depenses_actuelles + :montant - :old_montant WHERE nom = :categorie_name");
                $updateCategoryStmt->execute([':montant' => $montant, ':old_montant' => $old_montant, ':categorie_name' => $categorie_name]);
            }

            // Succès
            $message = "La dépense a été mise à jour avec succès.";
            $message_type = 'success';
            $show_form = false; // Cache le formulaire après succès
        } else {
            // Si la dépense n'existe pas
            $message = "La dépense sélectionnée n'existe pas.";
            $message_type = 'error';
            $show_form = false;
        }
    } catch (Exception $e) {
        // Échec
        $message = "Une erreur est survenue : " . $e->getMessage();
        $message_type = 'error';
        $show_form = false; // Cache également le formulaire en cas d'erreur
    }
}

// Récupérer les dépenses et catégories pour le formulaire
$depenses = $pdo->query("SELECT * FROM depenses")->fetchAll(PDO::FETCH_ASSOC);
$categories = $pdo->query("SELECT nom FROM categories")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier une Dépense</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(145deg, #6a11cb, #2575fc);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 0 20px;
        }

        .container {
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            padding: 40px;
            text-align: center;
            width: 100%;
            max-width: 900px;
            transition: transform 0.3s ease-in-out;
        }

        .container:hover {
            transform: scale(1.02);
        }

        h1 {
            font-size: 28px;
            margin-bottom: 30px;
            color: #2C3E50;
            font-weight: bold;
            text-transform: uppercase;
        }

        form {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 25px;
            margin-bottom: 30px;
        }

        label {
            font-size: 16px;
            font-weight: bold;
            color: #555;
            display: block;
        }

        select, input, textarea {
            width: 100%;
            padding: 15px;
            border: 2px solid #ccc;
            border-radius: 10px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }

        select:focus, input:focus, textarea:focus {
            border-color: #2575fc;
            outline: none;
        }

        button {
            grid-column: span 2;
            padding: 15px;
            background-color: #FF6347;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: bold;
            text-transform: uppercase;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-top: 15px;
        }

        button:hover {
            background-color: #FF4500;
        }

        .message {
            margin-top: 20px;
            padding: 15px;
            border-radius: 10px;
            font-size: 16px;
            width: 100%;
        }

        .message.success {
            background-color: #5cb85c;
            color: white;
            border: 2px solid #4cae4c;
        }

        .message.error {
            background-color: #f44336;
            color: white;
            border: 2px solid #e53935;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        .message {
            animation: fadeIn 0.5s ease-out;
        }

    </style>
</head>
<body>
    <div class="container">
        <h1>Modifier une Dépense</h1>
        
        <?php if ($show_form): ?>
            <form method="POST">
                <label for="nom_depense">Sélectionnez une Dépense :</label>
                <select name="nom_depense" id="nom_depense" required>
                    <option value="" disabled selected>Choisissez une dépense</option>
                    <?php foreach ($depenses as $dep): ?>
                        <option value="<?= htmlspecialchars($dep['nom_depense']) ?>">
                            <?= htmlspecialchars($dep['nom_depense']) ?> - <?= htmlspecialchars($dep['montant']) ?>Dh
                        </option>
                    <?php endforeach; ?>
                </select>

                <label for="montant">Nouveau Montant :</label>
                <input type="number" name="montant" id="montant" step="0.01" required>

                <label for="categorie_name">Nouvelle Catégorie :</label>
                <select name="categorie_name" id="categorie_name" required>
                    <option value="" disabled selected>Choisissez une catégorie</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= htmlspecialchars($cat['nom']) ?>">
                            <?= htmlspecialchars($cat['nom']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label for="mode_paiement">Nouveau Mode de Paiement :</label>
                <input type="text" name="mode_paiement" id="mode_paiement" required>

                <label for="commentaire">Nouveau Commentaire :</label>
                <textarea name="commentaire" id="commentaire" rows="4"></textarea>

                <button type="submit" class="btn">Modifier</button>
            </form>
        <?php else: ?>
            <div class="message <?= htmlspecialchars($message_type) ?>">
                <?= htmlspecialchars($message) ?>
            </div>
            <a href="modif_depense.php" class="btn"><?= $message_type === 'success' ? 'Retour' : 'Réessayer' ?></a>
        <?php endif; ?>
    </div>
</body>
</html>
