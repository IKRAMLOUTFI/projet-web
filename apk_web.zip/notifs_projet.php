<?php
// Démarrer la session
session_start();
include("PDO_projet.php");

// Activer l'affichage des erreurs pour débogage
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    // Récupérer toutes les catégories et leurs budgets
    $categories = $pdo->query("SELECT nom, budget_mensuel, depenses_actuelles FROM categories")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    die("Erreur lors de la récupération des données : " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications des Budgets par Catégorie</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(145deg, #8E44AD, #2980B9);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 0 20px;
        }

        .container {
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            padding: 30px 40px;
            text-align: center;
            width: 90%; /* Ajuster la largeur */
            max-width: 800px;
            animation: slideIn 0.5s ease-out;
        }

        h1 {
            font-size: 28px;
            margin-bottom: 25px;
            color: #2C3E50;
            font-weight: bold;
        }

        .notification {
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
            text-align: left;
            font-size: 16px;
            font-weight: bold;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .notification.success {
            background-color: #e6ffe6;
            border: 1px solid #33cc33;
            color: #006600;
        }

        .notification.warning {
            background-color: #fff8e6;
            border: 1px solid #ffcc00;
            color: #996600;
        }

        .notification.error {
            background-color: #ffe6e6;
            border: 1px solid #ff3333;
            color: #cc0000;
        }

        .notification:hover {
            transform: scale(1.02);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }

        .footer {
            margin-top: 20px;
            font-size: 14px;
            color: #777;
        }

        @keyframes slideIn {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Notifications des Budgets par Catégorie</h1>

        <?php if (!empty($categories)): ?>
            <?php foreach ($categories as $cat): ?>
                <?php
                    $nom = htmlspecialchars($cat['nom']);
                    $budget = $cat['budget_mensuel'];
                    $depenses = $cat['depenses_actuelles'];
                    $reste = $budget - $depenses;

                    // Déterminer le type de notification
                    if ($reste <= 0) {
                        $type = 'error';
                        $message = "❌ Vous avez dépassé le budget de la catégorie <strong>$nom</strong>.";
                    } elseif ($reste <= $budget / 2) {
                        $type = 'warning';
                        $message = "⚠️ Attention : vous avez dépassé la moitié du budget de la catégorie <strong>$nom</strong>. Il reste $reste DH.";
                    } else {
                        $type = 'success';
                        $message = "✅ Votre budget pour la catégorie <strong>$nom</strong> est encore suffisant. Il reste $reste DH.";
                    }
                ?>

                <div class="notification <?= $type ?>">
                    <?= $message ?>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Aucune catégorie trouvée dans la base de données.</p>
        <?php endif; ?>

        <div class="footer">
        </div>
    </div>
</body>
</html>
