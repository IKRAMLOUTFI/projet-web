<?php
session_start();
include("PDO_projet.php");

// Initialisation des variables de recherche
$type_recherche = isset($_POST['type_recherche']) ? $_POST['type_recherche'] : '';
$mois = isset($_POST['mois']) ? $_POST['mois'] : '';
$categorie = isset($_POST['categorie']) ? $_POST['categorie'] : '';

// Initialiser les variables pour les résultats de recherche
$depenses = [];
$categorie_info = null;

if ($type_recherche == 'mois' && $mois) {
    // Rechercher les dépenses par mois
    $sql = "SELECT * FROM depenses WHERE DATE_FORMAT(datee, '%Y-%m') = :mois";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':mois', $mois);
    $stmt->execute();
    $depenses = $stmt->fetchAll(PDO::FETCH_ASSOC);
} elseif ($type_recherche == 'categorie' && $categorie) {
    // Rechercher les dépenses par catégorie
    $sql = "SELECT * FROM depenses WHERE categorie_name = :categorie";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':categorie', $categorie);
    $stmt->execute();
    $depenses = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Récupérer les informations de la catégorie
    $categorie_details = $pdo->prepare("SELECT * FROM categories WHERE nom = :categorie");
    $categorie_details->bindParam(':categorie', $categorie);
    $categorie_details->execute();
    $categorie_info = $categorie_details->fetch(PDO::FETCH_ASSOC);
}

// Récupérer les catégories pour le menu déroulant
$categories = $pdo->query("SELECT nom FROM categories")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recherche des Dépenses</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(145deg, #8E44AD, #2980B9);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 0 20px;
        }

        .container {
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            padding: 30px 40px;
            text-align: center;
            width: 80%;
            max-width: 800px;
            animation: slideIn 0.5s ease-out;
        }

        h1 {
            font-size: 28px;
            margin-bottom: 20px;
            color: #2C3E50;
            font-weight: bold;
        }

        form {
            margin-bottom: 30px;
        }

        label {
            font-size: 16px;
            font-weight: bold;
            color: #555;
            display: block;
            margin-bottom: 8px;
        }

        select, input {
            width: 100%;
            padding: 12px;
            border: 2px solid #ccc;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s ease;
        }

        select:focus, input:focus {
            border-color: #2980B9;
            outline: none;
        }

        button {
            width: 100%;
            padding: 15px;
            background-color: #FF6347;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: bold;
            text-transform: uppercase;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #FF4500;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ccc;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #4caf50;
            color: white;
        }

        @keyframes slideIn {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Rechercher des Dépenses</h1>

        <form method="POST">
            <!-- Choisir le type de recherche -->
            <label for="type_recherche">Choisir un type de recherche :</label>
            <select name="type_recherche" id="type_recherche" required>
                <option value="" disabled selected>Choisissez un type de recherche</option>
                <option value="mois" <?= $type_recherche == 'mois' ? 'selected' : '' ?>>Par Mois</option>
                <option value="categorie" <?= $type_recherche == 'categorie' ? 'selected' : '' ?>>Par Catégorie</option>
            </select>
            <br><br>

            <!-- Recherche par mois -->
            <?php if ($type_recherche == 'mois'): ?>
                <label for="mois">Sélectionnez un mois :</label>
                <input type="month" name="mois" id="mois" value="<?= htmlspecialchars($mois) ?>">
            <?php endif; ?>

            <!-- Recherche par catégorie -->
            <?php if ($type_recherche == 'categorie'): ?>
                <label for="categorie">Sélectionnez une catégorie :</label>
                <select name="categorie" id="categorie">
                    <option value="" disabled selected>Choisissez une catégorie</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= htmlspecialchars($cat['nom']) ?>" <?= $categorie == $cat['nom'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['nom']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            <?php endif; ?>

            <br><br>
            <button type="submit">Rechercher</button>
        </form>

        <!-- Affichage des résultats de recherche -->
        <?php if ($type_recherche && !$depenses): ?>
            <p>Aucune dépense trouvée selon les critères sélectionnés.</p>
        <?php endif; ?>

        <?php if ($depenses): ?>
            <table>
                <tr>
                    <th>Nom Dépense</th>
                    <th>Montant</th>
                    <th>Date</th>
                    <th>Catégorie</th>
                    <th>Mode de Paiement</th>
                    <th>Commentaire</th>
                </tr>
                <?php foreach ($depenses as $dep): ?>
                    <tr>
                        <td><?= htmlspecialchars($dep['nom_depense']) ?></td>
                        <td><?= htmlspecialchars($dep['montant']) ?> €</td>
                        <td><?= htmlspecialchars($dep['datee']) ?></td>
                        <td><?= htmlspecialchars($dep['categorie_name']) ?></td>
                        <td><?= htmlspecialchars($dep['mode_paiement']) ?></td>
                        <td><?= htmlspecialchars($dep['commentaire']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>

            <!-- Affichage des détails de la catégorie (si recherche par catégorie) -->
            <?php if ($type_recherche == 'categorie' && $categorie_info): ?>
                <table>
                    <tr>
                        <th>Budget Mensuel</th>
                        <th>Dépenses Actuelles</th>
                        <th>Reste</th>
                        <th>Date de Création</th>
                    </tr>
                    <tr>
                        <td><?= htmlspecialchars($categorie_info['budget_mensuel']) ?> Dh</td>
                        <td><?= htmlspecialchars($categorie_info['depenses_actuelles']) ?> Dh</td>
                        <td><?= htmlspecialchars($categorie_info['reste']) ?> Dh</td>
                        <td><?= htmlspecialchars($categorie_info['date_creation']) ?></td>
                    </tr>
                </table>
            <?php endif; ?>

        <?php endif; ?>
    </div>
</body>
</html>
