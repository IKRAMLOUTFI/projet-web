

<?php
    session_start();
    include("PDO_projet.php");

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Récupérer les valeurs du formulaire
        $username = $_POST['username'] ?? '';
        $password = $_POST['pasword'] ?? ''; // Correction du nom de variable 'pasword' à 'password'
        $email = $_POST['email'] ?? '';

        // Préparer la requête SQL d'insertion
        $sql = "INSERT INTO users (username, pasword, email) VALUES (:username, :pasword, :email)";
        $stmt = $pdo->prepare($sql);

        // Exécution de la requête avec les paramètres
        $stmt->execute([
            ':username' => $username,
            ':pasword' => $password,  // Veuillez vérifier que vous utilisez 'pasword' dans la table
            ':email' => $email
        ]);

        // Message de confirmation et redirection après insertion réussie
        echo "Compte créé avec succès!";
        header("Location: test11.html");
    } else {
        // Message d'erreur si la requête n'est pas de type POST
        echo "Erreur produite";
    }
?>


